import os
import json
from datetime import datetime

SCAN_DIR = os.path.expanduser("~/Downloads")
CLUTTER_EXTENSIONS = {".dmg", ".pkg", ".zip", ".log", ".tmp", ".old"}
AGE_THRESHOLD_DAYS = 180
SIZE_THRESHOLD_MB = 100

def is_clutter(file_path, stat):
    reasons = []
    ext = os.path.splitext(file_path)[1].lower()
    if ext in CLUTTER_EXTENSIONS:
        reasons.append("clutter_extension")
    size_mb = stat.st_size / (1024 * 1024)
    if size_mb > SIZE_THRESHOLD_MB:
        reasons.append("large_file")
    days_old = (datetime.now() - datetime.fromtimestamp(stat.st_mtime)).days
    if days_old > AGE_THRESHOLD_DAYS:
        reasons.append("very_old")
    return reasons

clutter_candidates = []

for root, _, files in os.walk(SCAN_DIR):
    for fname in files:
        try:
            path = os.path.join(root, fname)
            stat = os.stat(path)
            reasons = is_clutter(path, stat)
            if reasons:
                clutter_candidates.append({
                    "path": path,
                    "size_mb": round(stat.st_size / (1024 * 1024), 2),
                    "last_modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    "reasons": reasons
                })
        except Exception:
            continue

report = {
    "scanned_at": datetime.now().isoformat(),
    "scanned_folder": SCAN_DIR,
    "clutter_candidates": clutter_candidates,
    "total_clutter_files": len(clutter_candidates),
}

with open("report.json", "w") as f:
    json.dump(report, f, indent=2)
